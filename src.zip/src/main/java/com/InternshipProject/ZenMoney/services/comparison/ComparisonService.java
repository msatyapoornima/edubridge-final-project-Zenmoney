package com.InternshipProject.ZenMoney.services.comparison;

import java.util.List;
import com.InternshipProject.ZenMoney.dto.ComparisonDTO;

public interface ComparisonService {

    List<ComparisonDTO> compareThisMonthAndLastMonth(Long userId);

    
}





/**
 * Service interface to define the contract for category-wise
 * monthly comparison of income and expenses.
 * Compares user's income and expense categories between this month and last month.
 *
 * @param userId the ID of the user
 * @return list of ComparisonDTO containing category, type, this month and last month totals
 * 
 * This interface is implemented by ComparisonServiceImpl,
 * which performs the actual data retrieval and comparison logic.
 */