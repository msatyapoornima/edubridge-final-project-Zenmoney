package com.InternshipProject.ZenMoney.services.Jwt;

import com.InternshipProject.ZenMoney.dto.JwtRequestDTO;
import com.InternshipProject.ZenMoney.dto.JwtResponseDTO;
import com.InternshipProject.ZenMoney.entity.User;

public interface JwtService {
    JwtResponseDTO createJwtToken(JwtRequestDTO jwtRequest);
    
    String generateToken(User user);
    
    Long extractUserId(String token);

}