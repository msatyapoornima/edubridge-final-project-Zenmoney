package com.InternshipProject.ZenMoney.services.savings;

import com.InternshipProject.ZenMoney.dto.SavingsComparisonDTO;
import com.InternshipProject.ZenMoney.entity.Savings;
import com.InternshipProject.ZenMoney.entity.User;

import java.util.List;

public interface SavingsService {

    Savings saveSavingsGoal(Savings savings);

    Savings updateSavingsGoal(Long id, Savings savings);

    void deleteSavingsGoal(Long id);

    List<Savings> getSavingsGoalsByUser(User user);

    // The key method for your savings comparison
    SavingsComparisonDTO compareSavings(User user, int month, int year);

    // Optional: Get the current savings goal for a user for a month/year
    Savings getCurrentSavingsGoal(User user, int month, int year);

    void deleteSavingsGoalById(Long id, User user);

    // **New method for stopping a savings goal**
    void stopSavingsGoal(Long id, User user);

}