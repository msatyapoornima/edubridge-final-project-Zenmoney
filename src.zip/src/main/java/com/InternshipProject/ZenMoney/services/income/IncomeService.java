package com.InternshipProject.ZenMoney.services.income;

import java.math.BigDecimal;
import java.util.List;

import com.InternshipProject.ZenMoney.dto.IncomeDTO;
import com.InternshipProject.ZenMoney.entity.Income;
import com.InternshipProject.ZenMoney.entity.User;

public interface IncomeService {

    void deleteIncome(Long id, Long userId);

    Income getIncomeById(Long id, Long userId);

    Income postIncome(IncomeDTO incomeDTO, Long userId);

    Income updateIncome(Long id, IncomeDTO incomeDTO, Long userId);

    List<IncomeDTO> getAllIncomes(Long userId);

    List<Income> findByCategoryAndUserId(String category, Long userId);

    List<Income> findByTitleContainingIgnoreCaseAndUserId(String title, Long userId);

    List<Income> findByUser_Id(Long userId);

    BigDecimal sumByUserIdAndCategoryAndMonth(Long userId, String category, int month, int year);

    // THIS WAS MISSING — Returns total income of user for given month and year
    BigDecimal getTotalIncomeByUserAndMonthYear(User user, int month, int year);
}