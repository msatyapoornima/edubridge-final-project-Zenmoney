package com.InternshipProject.ZenMoney.services.expense;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.InternshipProject.ZenMoney.dto.ExpenseDTO;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.ExpenseRepository;
import com.InternshipProject.ZenMoney.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ExpenseServiceImplementation implements ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final UserRepository userRepository;

    @Transactional
    @Override
    public Expense postExpense(ExpenseDTO expenseDTO, Long userId) {
        return saveOrUpdateExpense(new Expense(), expenseDTO, userId);
    }

    @Transactional
    private Expense saveOrUpdateExpense(Expense expense, ExpenseDTO expenseDTO, Long userId) {
        expense.setTitle(expenseDTO.getTitle());
        expense.setCreatedAt(expenseDTO.getCreatedAt() != null ? expenseDTO.getCreatedAt() : LocalDate.now());
        expense.setAmount(expenseDTO.getAmount());
        expense.setCategory(expenseDTO.getCategory());
        expense.setDescription(expenseDTO.getDescription());

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new EntityNotFoundException("User not found for id " + userId));
        expense.setUser(user);

        return expenseRepository.save(expense);
    }

    @Override
    public Expense getExpenseById(Long id, Long userId) {
        return expenseRepository.findById(id)
            .filter(expense -> expense.getUser().getId().equals(userId))
            .orElseThrow(() -> new AccessDeniedException("Expense not found or not owned by user"));
    }

    @Override
    @Transactional
    public Expense updateExpense(Long id, ExpenseDTO dto, Long userId) {
        Expense expense = expenseRepository.findById(id)
            .filter(e -> e.getUser().getId().equals(userId))
            .orElseThrow(() -> new EntityNotFoundException("Expense not found or not owned by user"));
        return saveOrUpdateExpense(expense, dto, userId);
    }

    @Override
    @Transactional
    public void deleteExpense(Long id, Long userId) {
        Expense expense = expenseRepository.findById(id)
            .filter(exp -> exp.getUser().getId().equals(userId))
            .orElseThrow(() -> new AccessDeniedException("Expense not found or not owned by user"));
        expenseRepository.delete(expense);
    }

    @Override
    public List<Expense> getAllExpenses(Long userId) {
        return expenseRepository.findByUser_Id(userId).stream()
            .sorted(Comparator.comparing(Expense::getCreatedAt, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
            .collect(Collectors.toList());
    }

    @Override
    public List<Expense> getExpenseByCategory(String category, Long userId) {
        List<Expense> listExpense = expenseRepository.findByCategoryAndUserId(category, userId);
        if (listExpense.isEmpty())
            throw new EntityNotFoundException("No expenses found for category: " + category);
        return listExpense;
    }

    @Override
    public List<Expense> findByTitleContainingIgnoreCase(String title, Long userId) {
        List<Expense> listExpense = expenseRepository.findByTitleContainingIgnoreCaseAndUserId(title, userId);
        if (listExpense.isEmpty())
            throw new EntityNotFoundException("No expenses found for title: " + title);
        return listExpense;
    }

    @Override
    public BigDecimal sumByUserIdAndCategoryAndMonth(Long userId, String category, int month, int year) {
        BigDecimal sum = expenseRepository.sumByUserIdAndCategoryAndMonth(userId, category, month, year);
        return sum != null ? sum : BigDecimal.ZERO;
    }
    
    @Override
    public BigDecimal getTotalExpenseByUserAndMonthYear(User user, int month, int year) {
        BigDecimal total = expenseRepository.getTotalExpenseForUserByMonth(user.getId(), month, year);
        return total != null ? total : BigDecimal.ZERO;
    }

}