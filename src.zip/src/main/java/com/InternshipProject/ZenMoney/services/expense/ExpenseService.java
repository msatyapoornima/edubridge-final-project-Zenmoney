package com.InternshipProject.ZenMoney.services.expense;

import java.math.BigDecimal;
import java.util.List;

import com.InternshipProject.ZenMoney.dto.ExpenseDTO;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.entity.User;

public interface ExpenseService {

    Expense getExpenseById(Long id, Long userId);

    Expense postExpense(ExpenseDTO expenseDTO, Long userId);

    Expense updateExpense(Long id, ExpenseDTO dto, Long userId);

    void deleteExpense(Long id, Long userId);

    List<Expense> getAllExpenses(Long userId);

    List<Expense> getExpenseByCategory(String category, Long userId);

    List<Expense> findByTitleContainingIgnoreCase(String title, Long userId);

    BigDecimal sumByUserIdAndCategoryAndMonth(Long userId, String category, int month, int year);

    // Add this method to get total expense of user for given month and year
    BigDecimal getTotalExpenseByUserAndMonthYear(User user, int month, int year);
}