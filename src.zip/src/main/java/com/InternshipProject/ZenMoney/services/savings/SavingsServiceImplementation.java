package com.InternshipProject.ZenMoney.services.savings;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.InternshipProject.ZenMoney.dto.SavingsComparisonDTO;
import com.InternshipProject.ZenMoney.entity.Savings;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.SavingsRepository;
import com.InternshipProject.ZenMoney.services.expense.ExpenseService;
import com.InternshipProject.ZenMoney.services.income.IncomeService;

@Service
public class SavingsServiceImplementation implements SavingsService {

    @Autowired
    private SavingsRepository savingsRepository;

    @Autowired
    private IncomeService incomeService;

    @Autowired
    private ExpenseService expenseService;

    @Override
    public Savings saveSavingsGoal(Savings savings) {
        return savingsRepository.save(savings);
    }

    @Override
    public Savings updateSavingsGoal(Long id, Savings savings) {
        Optional<Savings> existing = savingsRepository.findById(id);
        if (existing.isPresent()) {
            Savings toUpdate = existing.get();
            toUpdate.setGoal(savings.getGoal());
            toUpdate.setGoalName(savings.getGoalName());
            toUpdate.setMonth(savings.getMonth());
            toUpdate.setYear(savings.getYear());
            toUpdate.setUser(savings.getUser());
         
            return savingsRepository.save(toUpdate);
        }
        return null;
    }

    @Override
    public void deleteSavingsGoal(Long id) {
        savingsRepository.deleteById(id);
    }

    @Override
    public List<Savings> getSavingsGoalsByUser(User user) {
        return savingsRepository.findByUserOrderByYearDescMonthDesc(user);
    }

    @Override
    public Savings getCurrentSavingsGoal(User user, int month, int year) {
        List<Savings> goals = savingsRepository.findByUserAndMonthAndYear(user, month, year);
        return goals.isEmpty() ? null : goals.get(0);
    }

    @Override
    public SavingsComparisonDTO compareSavings(User user, int month, int year) {
        // Calculate previous month and year
        int prevMonth = month - 1;
        int prevYear = year;
        if (prevMonth == 0) {
            prevMonth = 12;
            prevYear = year - 1;
        }

        BigDecimal currentIncome = incomeService.getTotalIncomeByUserAndMonthYear(user, month, year);
        BigDecimal currentExpense = expenseService.getTotalExpenseByUserAndMonthYear(user, month, year);
        BigDecimal previousIncome = incomeService.getTotalIncomeByUserAndMonthYear(user, prevMonth, prevYear);
        BigDecimal previousExpense = expenseService.getTotalExpenseByUserAndMonthYear(user, prevMonth, prevYear);

        // Avoid nulls
        currentIncome = currentIncome == null ? BigDecimal.ZERO : currentIncome;
        currentExpense = currentExpense == null ? BigDecimal.ZERO : currentExpense;
        previousIncome = previousIncome == null ? BigDecimal.ZERO : previousIncome;
        previousExpense = previousExpense == null ? BigDecimal.ZERO : previousExpense;

        double currentSavings = currentIncome.subtract(currentExpense).doubleValue();
        double previousSavings = previousIncome.subtract(previousExpense).doubleValue();

        // Get goal for current month/year if any (SAFE null check)
        Savings currentGoal = getCurrentSavingsGoal(user, month, year);
        double goal = 0;
        if (currentGoal != null && currentGoal.getGoal() != null) {
            goal = currentGoal.getGoal().doubleValue();
        }

        return new SavingsComparisonDTO(currentSavings, previousSavings, goal);
    }
    
    @Override
    public void deleteSavingsGoalById(Long id, User user) {
        Savings savings = savingsRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Savings goal not found with id: " + id));

        if (!savings.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized to delete this savings goal");
        }
        savingsRepository.delete(savings);
    }

    // **New stop method implementation**
    @Override
    public void stopSavingsGoal(Long id, User user) {
        Savings savings = savingsRepository.findByIdAndUser(id, user)
            .orElseThrow(() -> new RuntimeException("Savings goal not found with id: " + id));

        if (!savings.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized to stop this savings goal");
        }

        // Mark stopped by setting goal to zero
        savings.setGoal(BigDecimal.ZERO);
        savingsRepository.save(savings);
    }
}