package com.InternshipProject.ZenMoney.services.auth;

import com.InternshipProject.ZenMoney.dto.AuthResponseDTO;
import com.InternshipProject.ZenMoney.dto.LoginRequestDTO;
import com.InternshipProject.ZenMoney.dto.RegisterRequestDTO;

public interface AuthService {

    AuthResponseDTO register(RegisterRequestDTO request);

    AuthResponseDTO login(LoginRequestDTO request); // Change to AuthResponseDTO
}