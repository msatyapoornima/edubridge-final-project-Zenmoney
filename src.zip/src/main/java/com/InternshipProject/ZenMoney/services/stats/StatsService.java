package com.InternshipProject.ZenMoney.services.stats;

import com.InternshipProject.ZenMoney.dto.GraphDTO;
import com.InternshipProject.ZenMoney.dto.StatsDTO;

public interface StatsService {
    GraphDTO getChartData(Long userId);
    StatsDTO getStats(Long userId);
}