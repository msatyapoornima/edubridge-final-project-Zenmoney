package com.InternshipProject.ZenMoney.services.auth;

import com.InternshipProject.ZenMoney.dto.AuthResponseDTO;
import com.InternshipProject.ZenMoney.dto.LoginRequestDTO;
import com.InternshipProject.ZenMoney.dto.RegisterRequestDTO;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.UserRepository;
import com.InternshipProject.ZenMoney.services.Jwt.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthServiceImplementation implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Override
    public AuthResponseDTO register(RegisterRequestDTO request) {
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .age(request.getAge())
                .gender(request.getGender())
                .location(request.getLocation())
                .build();

        userRepository.save(user);

        String token = jwtService.generateToken(user);
        return new AuthResponseDTO(token);
    }

    @Override
    public AuthResponseDTO login(LoginRequestDTO request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found!"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtService.generateToken(user);
        return new AuthResponseDTO(token);
    }
}