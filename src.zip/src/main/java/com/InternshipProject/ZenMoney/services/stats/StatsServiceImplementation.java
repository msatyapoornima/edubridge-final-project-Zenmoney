package com.InternshipProject.ZenMoney.services.stats;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.InternshipProject.ZenMoney.dto.GraphDTO;
import com.InternshipProject.ZenMoney.dto.StatsDTO;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.entity.Income;
import com.InternshipProject.ZenMoney.repository.ExpenseRepository;
import com.InternshipProject.ZenMoney.repository.IncomeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class StatsServiceImplementation implements StatsService {

    private final IncomeRepository incomeRepo;
    private final ExpenseRepository expenseRepo;

    @Override
    public GraphDTO getChartData(Long userId) {
        GraphDTO graphDTO = new GraphDTO();
        // Both repositories only filter by userId (no date range filtering available)
        graphDTO.setExpenseList(expenseRepo.findByUser_Id(userId));
        graphDTO.setIncomeList(incomeRepo.findByUser_Id(userId));
        return graphDTO;
    }

    @Override
    public StatsDTO getStats(Long userId) {
        double totalIncome = Optional.ofNullable(incomeRepo.sumAllAmountsForUser(userId)).orElse(0.0);
        double totalExpense = Optional.ofNullable(expenseRepo.sumAllAmountsForUser(userId)).orElse(0.0);

        Optional<Income> optionalIncome = incomeRepo.findFirstByUser_IdOrderByCreatedAtDesc(userId);
        Optional<Expense> optionalExpense = expenseRepo.findFirstByUser_IdOrderByCreatedAtDesc(userId);

        // Get all incomes and expenses for the user
        List<Income> incomeList = incomeRepo.findByUser_Id(userId);
        List<Expense> expenseList = expenseRepo.findByUser_Id(userId);

        StatsDTO statsDTO = new StatsDTO();
        statsDTO.setIncome(totalIncome);
        statsDTO.setExpense(totalExpense);
        statsDTO.setBalance(totalIncome - totalExpense);

        optionalIncome.ifPresent(statsDTO::setLatestIncome);
        optionalExpense.ifPresent(statsDTO::setLatestExpense);

        statsDTO.setMinIncome(incomeList.stream()
                .map(Income::getAmount)
                .min(Comparator.naturalOrder())
                .orElse(null));

        statsDTO.setMaxIncome(incomeList.stream()
                .map(Income::getAmount)
                .max(Comparator.naturalOrder())
                .orElse(null));

        statsDTO.setMinExpense(expenseList.stream()
                .map(Expense::getAmount)
                .min(Comparator.naturalOrder())
                .orElse(null));

        statsDTO.setMaxExpense(expenseList.stream()
                .map(Expense::getAmount)
                .max(Comparator.naturalOrder())
                .orElse(null));

        return statsDTO;
    }
}