package com.InternshipProject.ZenMoney.services.income;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.InternshipProject.ZenMoney.dto.IncomeDTO;
import com.InternshipProject.ZenMoney.entity.Income;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.IncomeRepository;
import com.InternshipProject.ZenMoney.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IncomeServiceImplementation implements IncomeService {

    private final IncomeRepository incomeRepository;
    private final UserRepository userRepository;

    @Override
    public Income postIncome(IncomeDTO incomeDTO, Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new EntityNotFoundException("User not found"));
        return saveOrUpdateIncome(new Income(), incomeDTO, user);
    }

    private Income saveOrUpdateIncome(Income income, IncomeDTO incomeDTO, User user) {
        income.setTitle(incomeDTO.getTitle());
        income.setCreatedAt(incomeDTO.getCreatedAt() != null ? incomeDTO.getCreatedAt() : LocalDate.now());
        income.setAmount(incomeDTO.getAmount());
        income.setCategory(incomeDTO.getCategory());
        income.setDescription(incomeDTO.getDescription());
        income.setUser(user);
        return incomeRepository.save(income);
    }

    @Override
    public List<IncomeDTO> getAllIncomes(Long userId) {
        return incomeRepository.findAllByUserId(userId).stream()
            .map(Income::getIncomeDto)
            .collect(Collectors.toList());
    }

    @Override
    public Income updateIncome(Long id, IncomeDTO incomeDTO, Long userId) {
        Income income = incomeRepository.findByIdAndUserId(id, userId)
            .orElseThrow(() -> new EntityNotFoundException("Income not found for id: " + id));
        return saveOrUpdateIncome(income, incomeDTO, income.getUser());
    }

    @Override
    public void deleteIncome(Long id, Long userId) {
        Income income = incomeRepository.findByIdAndUserId(id, userId)
            .orElseThrow(() -> new EntityNotFoundException("Income not found for id: " + id));
        incomeRepository.delete(income);
    }

    @Override
    public Income getIncomeById(Long id, Long userId) {
        return incomeRepository.findByIdAndUserId(id, userId)
            .orElseThrow(() -> new EntityNotFoundException("Income not found for id: " + id));
    }

    @Override
    public List<Income> findByCategoryAndUserId(String category, Long userId) {
        return incomeRepository.findByCategoryAndUserId(category, userId);
    }

    @Override
    public List<Income> findByTitleContainingIgnoreCaseAndUserId(String title, Long userId) {
        return incomeRepository.findByTitleContainingIgnoreCaseAndUserId(title, userId);
    }

    @Override
    public List<Income> findByUser_Id(Long userId) {
        return incomeRepository.findByUser_Id(userId);
    }

    @Override
    public BigDecimal sumByUserIdAndCategoryAndMonth(Long userId, String category, int month, int year) {
        BigDecimal sum = incomeRepository.sumByUserIdAndCategoryAndMonth(userId, category, month, year);
        return sum != null ? sum : BigDecimal.ZERO;
    }

    // *** Added missing method to avoid your error ***
    public BigDecimal getTotalIncomeByUserAndMonthYear(User user, int month, int year) {
        BigDecimal total = incomeRepository.sumByUserIdAndMonthAndYear(user.getId(), month, year);
        return total != null ? total : BigDecimal.ZERO;
    }
}