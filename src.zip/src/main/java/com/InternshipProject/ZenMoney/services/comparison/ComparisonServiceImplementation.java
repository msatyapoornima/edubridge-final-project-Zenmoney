package com.InternshipProject.ZenMoney.services.comparison;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.InternshipProject.ZenMoney.dto.ComparisonDTO;
import com.InternshipProject.ZenMoney.repository.ExpenseRepository;
import com.InternshipProject.ZenMoney.repository.IncomeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComparisonServiceImplementation implements ComparisonService {

    private final IncomeRepository incomeRepository;
    private final ExpenseRepository expenseRepository;

    private static final List<String> incomeCategories = List.of(
        "Salary", "Freelancing", "Investment Returns", "Stock Returns",
        "Bitcoin Returns", "Bank Transfer", "Youtube", "Miscellaneous"
    );

    private static final List<String> expenseCategories = List.of(
        "Bills", "Books", "Delivery", "Education", "Fine Dining",
        "Groceries", "Health", "Insurance", "Investment", "Miscellaneous",
        "Shopping", "Subscriptions", "Travelling"
    );

    @Override
    public List<ComparisonDTO> compareThisMonthAndLastMonth(Long userId) {
        LocalDate today = LocalDate.now();

        int thisMonth = today.getMonthValue();
        int lastMonth = thisMonth == 1 ? 12 : thisMonth - 1;
        int thisYear = today.getYear();
        int lastYear = thisMonth == 1 ? thisYear - 1 : thisYear;

        List<ComparisonDTO> result = new ArrayList<>();

        /// Income categories
        for (String category : incomeCategories) {
            BigDecimal thisMonthTotal = incomeRepository
                    .sumByUserIdAndCategoryAndMonth(userId, category, thisMonth, thisYear);

            BigDecimal lastMonthTotal = incomeRepository
                    .sumByUserIdAndCategoryAndMonth(userId, category, lastMonth, lastYear);

            if (!(thisMonthTotal.equals(BigDecimal.ZERO) && lastMonthTotal.equals(BigDecimal.ZERO))) {
                result.add(new ComparisonDTO(category, "INCOME", thisMonthTotal, lastMonthTotal));
            }
        }

        // Expense categories
        for (String category : expenseCategories) {
            BigDecimal thisMonthTotal = expenseRepository
                    .sumByUserIdAndCategoryAndMonth(userId, category, thisMonth, thisYear);

            BigDecimal lastMonthTotal = expenseRepository
                    .sumByUserIdAndCategoryAndMonth(userId, category, lastMonth, lastYear);

            if (!(thisMonthTotal.equals(BigDecimal.ZERO) && lastMonthTotal.equals(BigDecimal.ZERO))) {
                result.add(new ComparisonDTO(category, "EXPENSE", thisMonthTotal, lastMonthTotal));
            }
        }

        return result;
    }
}