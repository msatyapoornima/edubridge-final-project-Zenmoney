package com.InternshipProject.ZenMoney.services.Jwt;

import com.InternshipProject.ZenMoney.dto.JwtRequestDTO;
import com.InternshipProject.ZenMoney.dto.JwtResponseDTO;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.UserRepository;
import com.InternshipProject.ZenMoney.util.JwtUtil;

import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Service
@RequiredArgsConstructor
public class JwtServiceImplementation implements JwtService {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    @Override
    public JwtResponseDTO createJwtToken(JwtRequestDTO jwtRequest) {
        User user = userRepository.findByEmail(jwtRequest.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + jwtRequest.getEmail()));

        if (!passwordEncoder.matches(jwtRequest.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user);
        return new JwtResponseDTO(token);
    }
    
    @Override
    public String generateToken(User user) {
        return jwtUtil.generateToken(user);
    }
    
    @Override
    public Long extractUserId(String token) {
        String email = jwtUtil.extractUsername(token);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        return user.getId();
    }
}