package com.InternshipProject.ZenMoney.services.user;

import com.InternshipProject.ZenMoney.dto.RegisterRequestDTO;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public String registerUser(RegisterRequestDTO registerRequestDTO) {
        if (userRepository.findByEmail(registerRequestDTO.getEmail()).isPresent()) {
            return "Email is already in use.";
        }

        String encodedPassword = passwordEncoder.encode(registerRequestDTO.getPassword());

        User user = User.builder()
                .name(registerRequestDTO.getName())
                .email(registerRequestDTO.getEmail())
                .password(encodedPassword)
                .age(registerRequestDTO.getAge())
                .gender(registerRequestDTO.getGender())
                .location(registerRequestDTO.getLocation())
                .build();

        userRepository.save(user);

        return "User registered successfully!";
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }
}