package com.InternshipProject.ZenMoney.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.InternshipProject.ZenMoney.entity.Savings;
import com.InternshipProject.ZenMoney.entity.User;

@Repository
public interface SavingsRepository extends JpaRepository<Savings, Long> {

    List<Savings> findByUserAndMonthAndYear(User user, int month, int year);

    List<Savings> findByUserOrderByYearDescMonthDesc(User user);

    Optional<Savings> findByIdAndUser(Long id, User user);
}
