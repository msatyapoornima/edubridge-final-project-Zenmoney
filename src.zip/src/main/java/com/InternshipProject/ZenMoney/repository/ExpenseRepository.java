package com.InternshipProject.ZenMoney.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.InternshipProject.ZenMoney.entity.Expense;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

    List<Expense> findByCategoryAndUserId(String category, Long userId);

    List<Expense> findByTitleContainingIgnoreCaseAndUserId(String title, Long userId);

    List<Expense> findByUser_Id(Long userId);

    Optional<Expense> findFirstByUser_IdOrderByCreatedAtDesc(Long userId);

    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user.id = :userId")
    Double sumAllAmountsForUser(@Param("userId") Long userId);

    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user.id = :userId AND MONTH(e.createdAt) = :month AND YEAR(e.createdAt) = :year")
    BigDecimal getTotalExpenseForUserByMonth(Long userId, int month, int year);

    @Query("SELECT COALESCE(SUM(e.amount), 0) FROM Expense e " +
           "WHERE e.user.id = :userId AND e.category = :category AND FUNCTION('MONTH', e.createdAt) = :month AND FUNCTION('YEAR', e.createdAt) = :year")
    BigDecimal sumByUserIdAndCategoryAndMonth(@Param("userId") Long userId,
                                              @Param("category") String category,
                                              @Param("month") int month,
                                              @Param("year") int year);
}