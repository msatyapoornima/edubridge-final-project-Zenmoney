package com.InternshipProject.ZenMoney.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.InternshipProject.ZenMoney.entity.Income;

@Repository
public interface IncomeRepository extends JpaRepository<Income, Long> {

    // Find incomes by user ID
    List<Income> findAllByUserId(Long userId);

    // Find incomes by category and user ID
    List<Income> findByCategoryAndUserId(String category, Long userId);

    // Find incomes by title containing (case insensitive) and user ID
    List<Income> findByTitleContainingIgnoreCaseAndUserId(String title, Long userId);

    // Find incomes created between specific dates and user ID
    List<Income> findByUser_Id(Long userId);

    // Find income by ID and user ID
    Optional<Income> findByIdAndUserId(Long id, Long userId);

    // Find the most recent income for a specific user
    Optional<Income> findFirstByUser_IdOrderByCreatedAtDesc(Long userId);

    // Sum all amounts for a specific user
    @Query("SELECT SUM(i.amount) FROM Income i WHERE i.user.id = :userId")
    Double sumAllAmountsForUser(@Param("userId") Long userId);

    // Get total income for a user for a specific month and year
    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Income i " +
           "WHERE i.user.id = :userId AND FUNCTION('MONTH', i.createdAt) = :month AND FUNCTION('YEAR', i.createdAt) = :year")
    BigDecimal getTotalIncomeForUserByMonth(@Param("userId") Long userId,
                                        @Param("month") int month,
                                        @Param("year") int year);
    
    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Income i " +
            "WHERE i.user.id = :userId AND i.category = :category AND FUNCTION('MONTH', i.createdAt) = :month AND FUNCTION('YEAR', i.createdAt) = :year")
     BigDecimal sumByUserIdAndCategoryAndMonth(@Param("userId") Long userId,
                                               @Param("category") String category,
                                               @Param("month") int month,
                                               @Param("year") int year);
    
    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Income i WHERE i.user.id = :userId AND MONTH(i.createdAt) = :month AND YEAR(i.createdAt) = :year")
    BigDecimal sumByUserIdAndMonthAndYear(@Param("userId") Long userId, @Param("month") int month, @Param("year") int year);

}







/*
 * 💡 What does this class do?
 * 
 * This is a special helper interface for the Income table in the database.
 * It helps the program find and work with income records without writing complicated code.
 * 
 * Here's what it allows us to do:
 * 
 * 1. Find all incomes for a specific user.
 * 2. Filter incomes by category or title (searching).
 * 3. Get incomes between two dates (for a time range).
 * 4. Find a specific income using both ID and user.
 * 5. Get the latest income entry for a user.
 * 6. Calculate the total income of a user (sum of all income amounts).
 * 7. Calculate the total income for a specific month and year.
 * 
 * It's like a shortcut to ask the database questions about the Income data.
 */