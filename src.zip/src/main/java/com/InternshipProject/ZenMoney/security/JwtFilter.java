package com.InternshipProject.ZenMoney.security;

import com.InternshipProject.ZenMoney.util.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;                      // your JWT helper utility
    private final CustomUserDetailsService userDetailsService;  // inject your UserDetailsService implementation

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // Get the Authorization header from the request
        String authHeader = request.getHeader("Authorization");

        // Check if the header is missing or doesn't start with "Bearer "
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);  // continue chain without authentication
            return;
        }

        // Extract the token by removing the "Bearer " prefix
        String token = authHeader.substring(7);

        // Extract username (email) from token using your JwtUtil
        String username = jwtUtil.extractUsername(token);

        // Check if username is valid and if there is no authentication in the context yet
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

            // Load user details from your custom UserDetailsService
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);

            // Validate the token against the user details
            if (jwtUtil.isTokenValid(token, userDetails)) {

                // Create authentication token for Spring Security context
                UsernamePasswordAuthenticationToken authToken =
                        new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                // Set additional details (like remote IP)
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                // Set authentication to the SecurityContext to authorize the request
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }

        // Continue with the filter chain
        filterChain.doFilter(request, response);
    }
}