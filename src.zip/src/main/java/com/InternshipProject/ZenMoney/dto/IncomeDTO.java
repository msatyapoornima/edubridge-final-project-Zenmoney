package com.InternshipProject.ZenMoney.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class IncomeDTO {

    private Long id;
    private String title;
    private BigDecimal amount;
    private LocalDate createdAt;
    private String category;
    private String description;
    private Long userId;  // This field is added to represent the User's ID
}