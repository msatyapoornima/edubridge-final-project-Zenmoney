// ExpenseDTO.java
package com.InternshipProject.ZenMoney.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class ExpenseDTO {

    private Long id;                 // Expense id
    private String title;            // Title or name of the expense
    private String description;      // Description of the expense
    private String category;         // Expense category
    private LocalDate createdAt;     // Date of expense creation
    private BigDecimal amount;       // Amount spent
    private Long userId;             // User id linked to expense (used mostly internally)
}

/*
 * ExpenseDTO is a data transfer object used for receiving and sending expense info.
 * It keeps the external API clean and separated from internal entity models.
 */