package com.InternshipProject.ZenMoney.dto;

import java.math.BigDecimal;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.entity.Income;

import lombok.Data;

@Data
public class StatsDTO {
    
    private Double income;
    private Double expense;
    private Income latestIncome;
    private Expense latestExpense;
    private Double balance;
    private BigDecimal minIncome;
    private BigDecimal maxIncome;
    private BigDecimal minExpense;
    private BigDecimal maxExpense;
}