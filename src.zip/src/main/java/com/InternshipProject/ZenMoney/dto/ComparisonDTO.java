package com.InternshipProject.ZenMoney.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data  // Generates getters, setters, toString, equals, and hashcode methods
@AllArgsConstructor  // Generates constructor with all fields as parameters
public class ComparisonDTO {
    private String category;        // Category name (e.g., "Groceries")
    private String type;            // Type of category: "INCOME" or "EXPENSE"
    private BigDecimal thisMonthTotal;  // Total amount for the current month
    private BigDecimal lastMonthTotal;  // Total amount for the previous month

}



/*
 * This DTO (Data Transfer Object) holds the comparison data
 * for each category. It is not an entity and does not map
 * to the database. Instead, it is used to send data from
 * backend to frontend in a structured way.
 */