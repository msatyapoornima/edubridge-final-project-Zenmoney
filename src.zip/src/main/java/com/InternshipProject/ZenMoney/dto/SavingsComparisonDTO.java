package com.InternshipProject.ZenMoney.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SavingsComparisonDTO {
    private double currentMonthSavings;
    private double previousMonthSavings;
    private double goal;
}