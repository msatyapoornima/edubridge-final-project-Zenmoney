package com.InternshipProject.ZenMoney.dto;

import java.util.List;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.entity.Income;

import lombok.Data;

@Data
public class GraphDTO {
    
    private List<Expense> expenseList;
    private List<Income> incomeList;
}