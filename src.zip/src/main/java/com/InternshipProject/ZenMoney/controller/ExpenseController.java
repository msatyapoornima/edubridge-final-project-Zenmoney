package com.InternshipProject.ZenMoney.controller;

import java.math.BigDecimal;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.InternshipProject.ZenMoney.dto.ExpenseDTO;
import com.InternshipProject.ZenMoney.entity.Expense;
import com.InternshipProject.ZenMoney.security.CustomUserDetails;
import com.InternshipProject.ZenMoney.services.expense.ExpenseService;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/expense")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ExpenseController {

    private final ExpenseService expenseService;

    private Long getLoggedInUserId() {
        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userDetails.getId();
    }

    @PostMapping
    public ResponseEntity<?> postExpense(@RequestBody ExpenseDTO expenseDTO) {
        Long userId = getLoggedInUserId();
        try {
            Expense created = expenseService.postExpense(expenseDTO, userId);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to create expense.");
        }
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllExpenses() {
        Long userId = getLoggedInUserId();
        return ResponseEntity.ok(expenseService.getAllExpenses(userId));
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<?> getExpenseById(@PathVariable Long id) {
        Long userId = getLoggedInUserId();
        try {
            return ResponseEntity.ok(expenseService.getExpenseById(id, userId));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong! Try again later.");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateExpense(@PathVariable Long id, @RequestBody ExpenseDTO dto) {
        Long userId = getLoggedInUserId();
        try {
            return ResponseEntity.ok(expenseService.updateExpense(id, dto, userId));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong! Try again later.");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteExpense(@PathVariable Long id) {
        Long userId = getLoggedInUserId();
        try {
            expenseService.deleteExpense(id, userId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong! Try again later.");
        }
    }

    // Sum expenses by category and month for logged-in user
    @GetMapping("/sum")
    public ResponseEntity<?> sumByCategoryAndMonth(@RequestParam String category, @RequestParam int month, @RequestParam int year) {
        Long userId = getLoggedInUserId();
        try {
            BigDecimal sum = expenseService.sumByUserIdAndCategoryAndMonth(userId, category, month, year);
            return ResponseEntity.ok(sum);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to get sum of expenses.");
        }
    }
}