package com.InternshipProject.ZenMoney.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.InternshipProject.ZenMoney.dto.SavingsComparisonDTO;
import com.InternshipProject.ZenMoney.entity.Savings;
import com.InternshipProject.ZenMoney.entity.User;
import com.InternshipProject.ZenMoney.services.savings.SavingsService;
import com.InternshipProject.ZenMoney.services.user.UserService;

@RestController
@RequestMapping("/api/savings")
public class SavingsController {

    @Autowired
    private SavingsService savingsService;

    @Autowired
    private UserService userService;

    @PostMapping("/goal")
    public ResponseEntity<Savings> setGoal(@RequestBody Savings savings, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        savings.setUser(user);
        Savings savedGoal = savingsService.saveSavingsGoal(savings);
        return ResponseEntity.ok(savedGoal);
    }

    @GetMapping("/comparison")
    public ResponseEntity<SavingsComparisonDTO> getComparison(
            @RequestParam int month,
            @RequestParam int year,
            Principal principal) {

        User user = userService.findByEmail(principal.getName());
        SavingsComparisonDTO comparison = savingsService.compareSavings(user, month, year);
        return ResponseEntity.ok(comparison);
    }

    @GetMapping("/all-goals")
    public ResponseEntity<List<Savings>> getAllGoals(Principal principal) {
        User user = userService.findByEmail(principal.getName());
        List<Savings> allGoals = savingsService.getSavingsGoalsByUser(user);
        return ResponseEntity.ok(allGoals);
    }
    
    @DeleteMapping("/goal/{id}")
    public ResponseEntity<Void> deleteGoal(@PathVariable Long id, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        savingsService.deleteSavingsGoalById(id, user);
        return ResponseEntity.noContent().build();
    }

    // **New endpoint for stopping a goal**
    @PatchMapping("/goal/stop/{id}")
    public ResponseEntity<Void> stopGoal(@PathVariable Long id, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        savingsService.stopSavingsGoal(id, user);
        return ResponseEntity.noContent().build();
    }


    // **New endpoint for updating a goal**
    @PutMapping("/goal/{id}")
    public ResponseEntity<Savings> updateGoal(@PathVariable Long id, @RequestBody Savings savings, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        savings.setUser(user); // ensure the user is set correctly
        Savings updatedGoal = savingsService.updateSavingsGoal(id, savings);
        if (updatedGoal == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedGoal);
    }
}