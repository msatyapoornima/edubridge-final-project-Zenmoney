package com.InternshipProject.ZenMoney.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InternshipProject.ZenMoney.dto.AuthResponseDTO;
import com.InternshipProject.ZenMoney.dto.LoginRequestDTO;
import com.InternshipProject.ZenMoney.dto.RegisterRequestDTO;
import com.InternshipProject.ZenMoney.repository.UserRepository;
import com.InternshipProject.ZenMoney.services.Jwt.JwtService;
import com.InternshipProject.ZenMoney.services.auth.AuthService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final JwtService jwtService;
    private final UserRepository userRepository;

    @PostMapping("/register")
    public ResponseEntity<AuthResponseDTO> register(@RequestBody RegisterRequestDTO request) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponseDTO> login(@RequestBody LoginRequestDTO request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @GetMapping("/user")
    public ResponseEntity<?> getUserInfo(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7); // remove "Bearer "
        Long userId = jwtService.extractUserId(token);

        return userRepository.findById(userId)
                .map(user -> ResponseEntity.ok(new UserInfoResponse(
                        user.getName(),
                        user.getEmail(),
                        user.getGender()
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    // Inner class to return limited user data
    record UserInfoResponse(String name, String email, String gender) { }
}