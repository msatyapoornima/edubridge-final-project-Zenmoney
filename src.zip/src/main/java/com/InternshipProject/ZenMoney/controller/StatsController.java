package com.InternshipProject.ZenMoney.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.InternshipProject.ZenMoney.dto.GraphDTO;
import com.InternshipProject.ZenMoney.dto.StatsDTO;
import com.InternshipProject.ZenMoney.security.CustomUserDetails;
import com.InternshipProject.ZenMoney.services.stats.StatsService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/stats")
@RequiredArgsConstructor
@CrossOrigin("*")
public class StatsController {

    private final StatsService service;

    private Long getLoggedInUserId() {
        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();
        return userDetails.getId();
    }

    @GetMapping("/chart")
    public ResponseEntity<GraphDTO> getChartDetails() {
        Long userId = getLoggedInUserId();
        return ResponseEntity.ok(service.getChartData(userId));
    }

    @GetMapping
    public ResponseEntity<StatsDTO> getStats() {
        Long userId = getLoggedInUserId();
        return ResponseEntity.ok(service.getStats(userId));
    }
}