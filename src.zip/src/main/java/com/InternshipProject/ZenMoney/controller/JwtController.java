package com.InternshipProject.ZenMoney.controller;

import com.InternshipProject.ZenMoney.dto.JwtRequestDTO;
import com.InternshipProject.ZenMoney.dto.JwtResponseDTO;
import com.InternshipProject.ZenMoney.services.Jwt.JwtService;

import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin
public class JwtController {

    private final JwtService jwtService;

    @PostMapping("/authenticate")
    public JwtResponseDTO authenticate(@RequestBody JwtRequestDTO jwtRequest) {
        return jwtService.createJwtToken(jwtRequest);
    }
}