package com.InternshipProject.ZenMoney.controller;

import com.InternshipProject.ZenMoney.dto.RegisterRequestDTO;
import com.InternshipProject.ZenMoney.services.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String registerUser(@RequestBody RegisterRequestDTO registerRequestDTO) {
        return userService.registerUser(registerRequestDTO);
    }
}