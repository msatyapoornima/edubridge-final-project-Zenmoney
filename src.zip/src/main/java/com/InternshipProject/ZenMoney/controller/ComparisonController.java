package com.InternshipProject.ZenMoney.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InternshipProject.ZenMoney.dto.ComparisonDTO;
import com.InternshipProject.ZenMoney.services.Jwt.JwtService;
import com.InternshipProject.ZenMoney.services.comparison.ComparisonService;

import jakarta.servlet.http.HttpServletRequest;

@RestController  // Defines this as a REST controller to handle HTTP requests
@RequestMapping("/api/comparison")  // Base path for all endpoints in this controller
public class ComparisonController {

    @Autowired  // Injects ComparisonService dependency
    private ComparisonService comparisonService;

    @Autowired  // Injects JwtService for extracting user info from JWT token
    private JwtService jwtService;

    /**
     * HTTP GET endpoint to fetch category-wise monthly comparison data.
     * The user ID is extracted from the JWT token sent in the Authorization header.
     *
     * @param request the HttpServletRequest containing headers
     * @return List of ComparisonDTO objects containing category comparison data
     */
    @GetMapping("/month")
    public List<ComparisonDTO> getMonthlyComparison(HttpServletRequest request) {
        // Extract the token by removing "Bearer " prefix
        String token = request.getHeader("Authorization").substring(7);

        // Extract the user ID from the JWT token
        Long userId = jwtService.extractUserId(token);

        // Call service to get comparison data and return it
        return comparisonService.compareThisMonthAndLastMonth(userId);
    }
}

/*
 * This controller handles incoming HTTP requests related to
 * monthly comparisons of income and expenses by category.
 *
 * It uses JwtService to authenticate and identify the user,
 * then calls the ComparisonService to get the comparison data.
 *
 * The data is returned as JSON to the frontend to display or process.
 */