package com.InternshipProject.ZenMoney.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.InternshipProject.ZenMoney.dto.IncomeDTO;
import com.InternshipProject.ZenMoney.entity.Income;
import com.InternshipProject.ZenMoney.security.CustomUserDetails;
import com.InternshipProject.ZenMoney.services.income.IncomeService;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/income")
@RequiredArgsConstructor
@CrossOrigin("*")
public class IncomeController {

    private final IncomeService incomeService;

    private Long getLoggedInUserId() {
        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userDetails.getId();
    }

    @PostMapping
    public ResponseEntity<?> postIncome(@RequestBody IncomeDTO incomeDTO) {
        Long userId = getLoggedInUserId();
        Income created = incomeService.postIncome(incomeDTO, userId);
        if (created != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllIncomes() {
        Long userId = getLoggedInUserId();
        return ResponseEntity.ok(incomeService.getAllIncomes(userId));
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<?> getIncomeById(@PathVariable Long id) {
        Long userId = getLoggedInUserId();
        try {
            return ResponseEntity.ok(incomeService.getIncomeById(id, userId));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateIncome(@PathVariable Long id, @RequestBody IncomeDTO dto) {
        Long userId = getLoggedInUserId();
        try {
            return ResponseEntity.ok(incomeService.updateIncome(id, dto, userId));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteIncome(@PathVariable Long id) {
        Long userId = getLoggedInUserId();
        try {
            incomeService.deleteIncome(id, userId);
            return ResponseEntity.ok().body("Income deleted successfully");
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }
}