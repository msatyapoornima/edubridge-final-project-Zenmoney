package com.InternshipProject.ZenMoney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties
public class ZenMoneyApplication {
    public static void main(String[] args) {
        SpringApplication.run(ZenMoneyApplication.class, args);
    }
}


/*
 * This is the main class of the ZenMoney application.
 * 
 * It starts (runs) the entire Spring Boot application.
 * 
 * Here's what it does in simple words:
 * - Think of this like the "on" switch of the app. When you run this class, it turns everything on.
 * - The @SpringBootApplication part tells Spring Boot to automatically set up everything the app needs to work.
 * - The 'main' method is where the application begins. It's like the front door — once opened, the rest of the app gets activated.
 * 
 * If someone asks what this class does:
 * - It starts the ZenMoney application.
 * - It sets up everything the app needs behind the scenes.
 * - Without this class, the app won't run.
 */