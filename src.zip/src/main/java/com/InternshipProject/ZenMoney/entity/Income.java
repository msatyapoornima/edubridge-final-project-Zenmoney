package com.InternshipProject.ZenMoney.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.InternshipProject.ZenMoney.dto.IncomeDTO;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "income")
public class Income {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private BigDecimal amount;
    private LocalDate createdAt;
    private String category;
    private String description;

    @ManyToOne
    private User user;  // Reference to the User who created the income

    public IncomeDTO getIncomeDto() {
    	
        IncomeDTO dto = new IncomeDTO();
        
        dto.setTitle(this.title);
        
        dto.setAmount(this.amount);
        
        dto.setCategory(this.category);
        
        dto.setDescription(this.description);
        
        dto.setCreatedAt(this.createdAt);
        
        dto.setId(this.id);
        dto.setUserId(this.user != null ? this.user.getId() : null);

        
        // Possibly exclude user or ID if not needed
        return dto;
    }

}