// Expense.java (Entity)
package com.InternshipProject.ZenMoney.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "expense")
public class Expense {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;            // Title of the expense
    private String description;      // Description of the expense
    private String category;         // Category of the expense
    private LocalDate createdAt;     // Creation date of the expense
    private BigDecimal amount;       // Amount of expense

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;               // User who owns the expense
}

/*
 * Expense is a JPA entity representing the expenses table in DB.
 * It holds the expense details and links to the user who created it.
 */