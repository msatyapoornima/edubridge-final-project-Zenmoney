import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SavingsService {
  private baseUrl = 'http://localhost:8080/api/savings';

  constructor(private http: HttpClient) { }

  setGoal(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/goal`, data);
  }

  getAllGoals(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/all-goals`);
  }

  updateGoal(id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/goal/${id}`, data);
  }

  deleteGoal(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/goal/${id}`);
  }

  stopGoal(id: number): Observable<void> {
    return this.http.patch<void>(`${this.baseUrl}/goal/stop/${id}`, {});
  }

  getComparison(month: number, year: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/comparison`, {
      params: { month, year }
    });
  }
}