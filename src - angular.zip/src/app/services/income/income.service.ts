// income.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const BASE_URL = 'http://localhost:8080/api/income';

@Injectable({
  providedIn: 'root'
})
export class IncomeService {

  constructor(private http: HttpClient) { }

  createIncome(data: any): Observable<any> {
    return this.http.post(BASE_URL, data);
  }

  getAllIncomes(): Observable<any> {
    return this.http.get(`${BASE_URL}/all`);
  }

  getIncomeById(id: number): Observable<any> {
    return this.http.get(`${BASE_URL}/id/${id}`);
  }

  updateIncome(id: number, data: any): Observable<any> {
    return this.http.put(`${BASE_URL}/${id}`, data);
  }

  deleteIncome(id: number): Observable<any> {
    return this.http.delete(`${BASE_URL}/${id}`, { responseType: 'text' });
  }

}