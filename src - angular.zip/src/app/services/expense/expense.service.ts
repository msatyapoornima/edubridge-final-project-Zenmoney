import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const BASE_URL = 'http://localhost:8080/api/expense';

@Injectable({
  providedIn: 'root'
})
export class ExpenseService {

  constructor(private http: HttpClient) { }

  postExpense(expenseDTO: any): Observable<any> {
    return this.http.post(BASE_URL, expenseDTO);
  }

  getAllExpenses(): Observable<any> {
    return this.http.get(`${BASE_URL}/all`);
  }

  deleteExpense(id: number): Observable<any> {
    return this.http.delete(`${BASE_URL}/${id}`);
  }

  getExpenseById(id: number): Observable<any> {
    return this.http.get(`${BASE_URL}/id/${id}`);
  }

  updateExpense(id: number, expenseDTO: any): Observable<any> {
    return this.http.put(`${BASE_URL}/${id}`, expenseDTO);
  }
}