import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface ComparisonDTO {
  category: string;
  type: 'INCOME' | 'EXPENSE';
  thisMonthTotal: number;
  lastMonthTotal: number;
}

@Injectable({
  providedIn: 'root',
})
export class ComparisonService {
  // Use full URL to ensure interceptor applies Authorization header properly
  private baseUrl = 'http://localhost:8080/api/comparison';

  constructor(private http: HttpClient) { }

  getMonthlyComparison(): Observable<ComparisonDTO[]> {
    return this.http.get<ComparisonDTO[]>(`${this.baseUrl}/month`);
  }
}