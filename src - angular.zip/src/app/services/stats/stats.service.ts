import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const BASIC_URL = "http://localhost:8080/";

@Injectable({
  providedIn: 'root'
})
export class StatsService {

  constructor(private http: HttpClient) { }

  getStats(): Observable<any> {
    return this.http.get(BASIC_URL + "api/stats")
  }

  getChart(): Observable<any> {
    return this.http.get(BASIC_URL + "api/stats/chart")
  }

  getSavingGoal(): Observable<{ goal: number }> {
    return this.http.get<{ goal: number }>(`${BASIC_URL}api/savings/goal`);
  }

  setSavingGoal(goal: number): Observable<any> {
    return this.http.post(`${BASIC_URL}api/savings/goal`, { goalAmount: goal });
  }

  getComparison(): Observable<Array<{ current: number; previous: number; goal: number }>> {
    return this.http.get<Array<{ current: number; previous: number; goal: number }>>(`${BASIC_URL}api/savings/comparison`);
  }

}
