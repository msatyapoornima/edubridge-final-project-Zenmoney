import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  userName: string = 'Guest';
  userGender: string = 'other';
  userEmail: string = '';
  avatarUrl: string = 'assets/images/avatar-neutral.jpg';
  showSidebar: boolean = true;
  selectedMenuItem = '';

  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        const path = event.urlAfterRedirects;
        this.showSidebar = !(path.includes('/login') || path.includes('/register'));

        if (path.startsWith('/dashboard')) this.selectedMenuItem = 'dashboard';
        else if (path.startsWith('/income')) this.selectedMenuItem = 'income';
        else if (path.startsWith('/expense')) this.selectedMenuItem = 'expense';
        else if (path.startsWith('/comparison')) this.selectedMenuItem = 'comparison';
        else if (path.startsWith('/savings')) this.selectedMenuItem = 'savings';
        else this.selectedMenuItem = '';

        this.loadUserInfo();
      }
    });
  }

  ngOnInit(): void {
    this.loadUserInfo();
  }

  loadUserInfo(): void {
    const userJson = localStorage.getItem('user');
    if (userJson) {
      const user = JSON.parse(userJson);
      this.userName = user.name || 'User';
      this.userGender = user.gender || 'other';
      this.userEmail = user.email || '';
    }
    this.avatarUrl = this.getAvatar();
  }

  getAvatar(): string {
    switch (this.userGender.toUpperCase()) {
      case 'FEMALE': return 'assets/images/avatar-female.jpg';
      case 'MALE': return 'assets/images/avatar-male.jpg';
      default: return 'assets/images/avatar-neutral.jpg';
    }
  }

  onLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }
}