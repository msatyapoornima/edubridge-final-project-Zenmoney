import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth/auth.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(private authService: AuthService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.authService.getToken();

    // Add token for ALL requests going to backend server (http://localhost:8080)
    if (token && req.url.startsWith('http://localhost:8080')) {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', `Bearer ${token}`)
      });
      return next.handle(cloned);
    }

    // For relative URLs (e.g., '/api/comparison/month'), add token too
    // You can detect those by checking if URL starts with /api or is relative
    if (token && (req.url.startsWith('/api') || !req.url.startsWith('http'))) {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', `Bearer ${token}`)
      });
      return next.handle(cloned);
    }

    // Otherwise, no change
    return next.handle(req);
  }
}