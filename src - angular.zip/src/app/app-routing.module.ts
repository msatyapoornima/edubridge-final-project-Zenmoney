import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ExpenseComponent } from './components/expense/expense.component';
import { UpdateExpenseComponent } from './components/update-expense/update-expense.component';
import { IncomeComponent } from './components/income/income.component';
import { UpdateIncomeComponent } from './components/update-income/update-income.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SavingsGoalComponent } from './components/savings-goal/savings-goal.component';
import { ComparisonComponent } from './components/comparison/comparison.component';
import { RedirectComponent } from './components/redirect/redirect.component';
import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { AuthLayoutComponent } from './layouts/auth-layout/auth-layout.component';

import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: AuthLayoutComponent,
    children: [
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
      { path: '', redirectTo: 'login', pathMatch: 'full' }
    ]
  },
  {
    path: '',
    canActivate: [AuthGuard],
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'expense', component: ExpenseComponent },
      { path: 'income', component: IncomeComponent },
      { path: 'expense/:id/edit', component: UpdateExpenseComponent },
      { path: 'income/:id/edit', component: UpdateIncomeComponent },
      { path: 'savings', component: SavingsGoalComponent },
      { path: 'comparison', component: ComparisonComponent },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' } // redirect default authenticated path to dashboard

    ]
  },
  { path: '**', redirectTo: 'login' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }