// income.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import * as dayjs from 'dayjs';
import { Router } from '@angular/router';
import { IncomeService } from 'src/app/services/income/income.service';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.scss']
})
export class IncomeComponent implements OnInit {
  incomeForm!: FormGroup;
  incomes: any[] = [];

  listOfCategory: string[] = [
    "Salary", "Freelancing", "Investment Returns", "Stock Returns",
    "Bitcoin Returns", "Bank Transfer", "Youtube", "Miscellaneous"
  ];

  // Filters
  selectedCategory: string | null = null;
  searchTitle: string = '';

  // For edit mode
  updateMode: boolean = false;
  currentEditId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private incomeService: IncomeService,
    private message: NzMessageService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.incomeForm = this.fb.group({
      title: [null, Validators.required],
      amount: [null, Validators.required],
      createdAt: [null, Validators.required],
      category: [null, Validators.required],
      description: [null]
    });

    this.getAllIncomes();
  }

  submitForm(): void {
    if (this.incomeForm.invalid) {
      this.message.error('Please fill in all required fields.');
      return;
    }

    const formValue = {
      ...this.incomeForm.value,
      createdAt: dayjs(this.incomeForm.value.createdAt).format('YYYY-MM-DD')
    };

    if (this.updateMode && this.currentEditId !== null) {
      this.incomeService.updateIncome(this.currentEditId, formValue).subscribe({
        next: () => {
          this.message.success('Income updated successfully!', { nzDuration: 1000 });
          this.resetForm();
          this.getAllIncomes();
        },
        error: () => {
          this.message.error('Failed to update income.', { nzDuration: 5000 });
        }
      });
    } else {
      this.incomeService.createIncome(formValue).subscribe({
        next: () => {
          this.message.success('Income added successfully!', { nzDuration: 1000 });
          this.resetForm();
          this.getAllIncomes();
        },
        error: () => {
          this.message.error('Failed to add income.', { nzDuration: 5000 });
        }
      });
    }
  }

  getAllIncomes(): void {
    this.incomeService.getAllIncomes().subscribe({
      next: (res) => {
        this.incomes = res || [];
        this.applyFilters();
      },
      error: () => {
        this.message.error('Failed to fetch incomes.', { nzDuration: 5000 });
      }
    });
  }

  applyFilters(): void {
    let filtered = [...this.incomes];

    if (this.selectedCategory) {
      filtered = filtered.filter(i => i.category === this.selectedCategory);
    }

    if (this.searchTitle.trim()) {
      filtered = filtered.filter(i =>
        i.title.toLowerCase().includes(this.searchTitle.toLowerCase())
      );
    }

    this.incomes = filtered;
  }

  clearFilters(): void {
    this.selectedCategory = null;
    this.searchTitle = '';
    this.getAllIncomes();
  }

  updateIncome(id: number): void {
    this.router.navigateByUrl(`/income/${id}/edit`);
  }

  deleteIncome(id: number): void {
    this.incomeService.deleteIncome(id).subscribe({
      next: () => {
        this.message.success('Income deleted successfully!', { nzDuration: 1000 });
        this.getAllIncomes();
      },
      error: () => {
        this.message.error('Failed to delete income.', { nzDuration: 5000 });
      }
    });
  }

  resetForm(): void {
    this.incomeForm.reset();
    this.updateMode = false;
    this.currentEditId = null;
  }
}