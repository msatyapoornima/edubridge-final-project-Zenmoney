import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

import { Chart, registerables } from 'chart.js';
import { StatsService } from 'src/app/services/stats/stats.service';

Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit {

  @ViewChild('incomeLinechartRef') incomeCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('expenseLinechartRef') expenseCanvas!: ElementRef<HTMLCanvasElement>;

  incomeChart!: Chart;
  expenseChart!: Chart;

  stats: any = {};

  constructor(private statsService: StatsService) { }

  ngAfterViewInit(): void {
    this.fetchStats();
    this.fetchChartData();
  }

  fetchStats(): void {
    this.statsService.getStats().subscribe({
      next: (data) => {
        this.stats = data;
      },
      error: (err) => {
        console.error('Error fetching stats:', err);
      }
    });
  }

  fetchChartData(): void {
    this.statsService.getChart().subscribe({
      next: (data) => {
        const incomeList = data.incomeList || [];
        const expenseList = data.expenseList || [];

        const sortedIncome = [...incomeList].sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
        const sortedExpense = [...expenseList].sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );

        const incomeLabels = sortedIncome.map(entry => new Date(entry.createdAt).toLocaleDateString());
        const incomeAmounts = sortedIncome.map(entry => entry.amount);

        const expenseLabels = sortedExpense.map(entry => new Date(entry.createdAt).toLocaleDateString());
        const expenseAmounts = sortedExpense.map(entry => entry.amount);

        this.renderIncomeChart(incomeLabels, incomeAmounts);
        this.renderExpenseChart(expenseLabels, expenseAmounts);
      },
      error: (err) => {
        console.error('Error fetching chart data:', err);
      }
    });
  }

  renderIncomeChart(labels: string[], data: number[]): void {
    this.incomeChart = new Chart(this.incomeCanvas.nativeElement.getContext('2d')!, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Income',
          data,
          borderColor: '#4caf50',
          backgroundColor: 'rgba(76, 175, 80, 0.1)',
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { ticks: { color: '#5a4631' } },
          y: { ticks: { color: '#5a4631' } }
        }
      }
    });
  }

  renderExpenseChart(labels: string[], data: number[]): void {
    this.expenseChart = new Chart(this.expenseCanvas.nativeElement.getContext('2d')!, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Expense',
          data,
          borderColor: '#f44336',
          backgroundColor: 'rgba(244, 67, 54, 0.1)',
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { ticks: { color: '#5a4631' } },
          y: { ticks: { color: '#5a4631' } }
        }
      }
    });
  }
}