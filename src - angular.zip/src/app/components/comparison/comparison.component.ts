import { Component, OnInit } from '@angular/core';
import { ComparisonDTO, ComparisonService } from 'src/app/services/comparison/comparison.service';

@Component({
  selector: 'app-comparison',
  templateUrl: './comparison.component.html',
  styleUrls: ['./comparison.component.scss']
})
export class ComparisonComponent implements OnInit {
  comparisons: ComparisonDTO[] = [];

  constructor(private comparisonService: ComparisonService) { }

  ngOnInit(): void {
    this.loadComparisons();
  }

  loadComparisons() {
    this.comparisonService.getMonthlyComparison().subscribe(res => {
      this.comparisons = res;
    });
  }

  getColor(c: ComparisonDTO): string {
    const diff = c.thisMonthTotal - c.lastMonthTotal;
    if (c.type === 'INCOME') {
      if (diff > 0) return '#c8e6c9'; // light greenish (soft mint)
      else if (diff < 0) return '#ffccbc'; // light warm coral
      else return '#f5eddc'; // warm golden beige (no change)
    } else {
      // EXPENSE
      if (diff < 0) return '#c8e6c9'; // light greenish (expense decreased)
      else if (diff > 0) return '#ffccbc'; // light warm coral (expense increased)
      else return '#f5eddc'; // warm golden beige (no change)
    }
  }

  getDiff(c: ComparisonDTO): number {
    return c.thisMonthTotal - c.lastMonthTotal;
  }
}