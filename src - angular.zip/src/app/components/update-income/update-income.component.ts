import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import * as dayjs from 'dayjs';
import { IncomeService } from 'src/app/services/income/income.service';

@Component({
  selector: 'app-update-income',
  templateUrl: './update-income.component.html',
  styleUrls: ['./update-income.component.scss']
})
export class UpdateIncomeComponent implements OnInit {
  incomeForm!: FormGroup;
  listOfCategory: string[] = [
    "Salary", "Freelancing", "Investment Returns", "Stock Returns",
    "Bitcoin Returns", "Bank Transfer", "Youtube", "Miscellaneous"
  ];

  incomeId!: number;

  constructor(
    private fb: FormBuilder,
    private incomeService: IncomeService,
    private route: ActivatedRoute,
    private router: Router,
    private message: NzMessageService
  ) { }

  ngOnInit(): void {
    this.incomeForm = this.fb.group({
      title: ['', Validators.required],
      amount: [null, [Validators.required, Validators.min(0.01)]],
      createdAt: [null, Validators.required],
      category: [null, Validators.required],
      description: ['']
    });

    this.route.params.subscribe(params => {
      this.incomeId = +params['id'];
      if (this.incomeId) {
        this.loadIncome(this.incomeId);
      }
    });
  }

  loadIncome(id: number): void {
    this.incomeService.getIncomeById(id).subscribe({
      next: (income) => {
        this.incomeForm.patchValue({
          title: income.title,
          amount: income.amount,
          createdAt: income.createdAt ? dayjs(income.createdAt) : null,
          category: income.category,
          description: income.description
        });
      },
      error: () => {
        this.message.error('Failed to load income');
      }
    });
  }

  submitForm(): void {
    if (this.incomeForm.invalid) {
      this.message.error('Please fill all required fields correctly!');
      return;
    }



    this.incomeService.updateIncome(this.incomeId, this.incomeForm.value).subscribe({
      next: () => {
        this.message.success('Income updated successfully!', { nzDuration: 5000 });
        this.router.navigateByUrl('/income');
      },
      error: () => {
        this.message.error('Failed to update income!');
      }
    });
  }
}