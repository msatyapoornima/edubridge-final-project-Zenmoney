// src/app/components/redirect/redirect.component.ts

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-redirect',
  template: ''
})
export class RedirectComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    const token = localStorage.getItem('token');

    if (token) {
      // Logged in user → go to dashboard
      this.router.navigate(['/dashboard']);
    } else {
      // Not logged in → go to login page
      this.router.navigate(['/login']);
    }
  }
}