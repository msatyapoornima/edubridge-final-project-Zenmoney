import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { SavingsService } from 'src/app/services/savings/savings.service';

@Component({
  selector: 'app-savings-goal',
  templateUrl: './savings-goal.component.html',
  styleUrls: ['./savings-goal.component.scss']
})
export class SavingsGoalComponent implements OnInit {
  savingsForm!: FormGroup;
  pastGoals: any[] = [];
  editing: boolean = false;
  editingGoalId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private savingsService: SavingsService,
    private message: NzMessageService
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.loadGoals();
  }

  initForm(): void {
    this.savingsForm = this.fb.group({
      goalName: ['', Validators.required],
      goal: [null, [Validators.required, Validators.min(1)]],
      month: [null, [Validators.required, Validators.min(1), Validators.max(12)]],
      year: [null, [Validators.required, Validators.min(2000)]],
    });
  }

  loadGoals(): void {
    this.savingsService.getAllGoals().subscribe(goals => {
      this.pastGoals = goals.map(goal => ({
        ...goal,
        stopped: !!goal.stopped,
        currentSavings: 0
      }));

      this.pastGoals.forEach((goal, index) => {
        this.savingsService.getComparison(goal.month, goal.year).subscribe(
          (comparison: any) => {
            const income = comparison?.income ?? 0;
            const expense = comparison?.expense ?? 0;
            const currentSaved = income - expense;
            this.pastGoals[index].currentSavings = currentSaved;
          },
          error => {
            console.error(`Failed to fetch comparison for goal id ${goal.id}`, error);
          }
        );
      });
    });
  }

  onSubmit(): void {
    if (this.savingsForm.invalid) return;

    const formValue = this.savingsForm.value;

    const payload = {
      goalName: formValue.goalName,
      goal: formValue.goal,
      month: formValue.month,
      year: formValue.year
    };

    if (this.editing && this.editingGoalId !== null) {
      this.savingsService.updateGoal(this.editingGoalId, payload).subscribe(() => {
        this.loadGoals();
        this.cancelEdit();
        this.message.success('Goal updated successfully');
      }, () => {
        this.message.error('Failed to update goal');
      });
    } else {
      this.savingsService.setGoal(payload).subscribe(() => {
        this.loadGoals();
        this.savingsForm.reset();
        this.message.success('Goal added successfully');
      }, () => {
        this.message.error('Failed to add goal');
      });
    }
  }

  onStopGoal(goal: any): void {
    this.savingsService.stopGoal(goal.id).subscribe({
      next: () => {
        this.message.success('Goal stopped successfully');
        goal.stopped = true;
      },
      error: (err) => {
        console.error('Failed to stop goal', err);
        this.message.error('Failed to stop goal');
      }
    });
  }

  editGoal(goal: any): void {
    this.savingsForm.patchValue({
      goalName: goal.goalName,
      goal: goal.goal,   // <-- Corrected here from goalAmount to goal
      month: goal.month,
      year: goal.year,
    });
    this.editing = true;
    this.editingGoalId = goal.id;
  }

  cancelEdit(): void {
    this.editing = false;
    this.editingGoalId = null;
    this.savingsForm.reset();
  }

  deleteGoal(goal: any): void {
    this.savingsService.deleteGoal(goal.id).subscribe(() => {
      this.loadGoals();
      this.message.success('Goal deleted successfully');
    }, () => {
      this.message.error('Failed to delete goal');
    });
  }
}