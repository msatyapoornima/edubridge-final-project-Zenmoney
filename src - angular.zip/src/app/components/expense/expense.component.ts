import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { ExpenseService } from 'src/app/services/expense/expense.service';

@Component({
  selector: 'app-expense',
  templateUrl: './expense.component.html',
  styleUrls: ['./expense.component.scss']
})
export class ExpenseComponent implements OnInit {
  expenseForm!: FormGroup;
  expenses: any[] = [];

  listOfCategory: string[] = [
    "Bills", "Books", "Delivery", "Education", "Fine Dining",
    "Groceries", "Health", "Insurance", "Investment", "Miscellaneous",
    "Shopping", "Subscriptions", "Travelling"
  ];

  // Filters
  selectedCategory: string | null = null;
  searchTitle: string = '';
  selectedDateRange: Date[] = [];

  constructor(
    private fb: FormBuilder,
    private expenseService: ExpenseService,
    private message: NzMessageService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.expenseForm = this.fb.group({
      title: [null, Validators.required],
      amount: [null, Validators.required],
      createdAt: [null, Validators.required],  // Matches backend field
      category: [null, Validators.required],
      description: [null],
    });

    this.getAllExpense();
  }

  submitForm(): void {
    if (this.expenseForm.invalid) {
      this.message.error("Please fill in all required fields.");
      return;
    }

    this.expenseService.postExpense(this.expenseForm.value).subscribe({
      next: () => {
        this.message.success("Expense posted successfully!", { nzDuration: 500 });
        this.expenseForm.reset();
        this.getAllExpense();
      },
      error: () => {
        this.message.error("Error while posting expense!", { nzDuration: 1000 });
      }
    });
  }

  getAllExpense(): void {
    this.expenseService.getAllExpenses().subscribe(res => {
      this.expenses = res || [];
      this.applyFilters();
    });
  }

  deleteExpense(id: number): void {
    this.expenseService.deleteExpense(id).subscribe({
      next: () => {
        this.message.success("Expense deleted successfully!", { nzDuration: 1000 });
        this.getAllExpense();
      },
      error: () => {
        this.message.error("Error while deleting expense.", { nzDuration: 5000 });
      }
    });
  }

  updateExpense(id: number): void {
    this.router.navigateByUrl(`expense/${id}/edit`);
  }

  applyFilters(): void {
    let filtered = [...this.expenses];

    if (this.selectedCategory) {
      filtered = filtered.filter(e => e.category === this.selectedCategory);
    }

    if (this.searchTitle.trim()) {
      filtered = filtered.filter(e =>
        e.title.toLowerCase().includes(this.searchTitle.toLowerCase())
      );
    }

    this.expenses = filtered;
  }

  clearFilters(): void {
    this.selectedCategory = null;
    this.searchTitle = '';
    this.getAllExpense();
  }
}