import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent {
  email = '';
  password = '';
  error = '';
  success = '';

  constructor(private auth: AuthService, private router: Router) { }

  showPassword = false;

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  onLogin() {
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: (res: any) => {
        this.auth.setToken(res.token);
        // NEW: Fetch user info and save
        this.auth.getUserInfo().subscribe(user => {
          localStorage.setItem('user', JSON.stringify(user));
          this.success = 'Login successful! Redirecting to dashboard.';
          this.error = '';
          this.router.navigate(['/dashboard']);
        });
      },
      error: () => {
        this.error = 'Invalid credentials!';
        this.success = '';
      }
    });
  }

}