import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  age!: number;
  gender = '';
  location = '';
  error = '';
  success = '';

  constructor(private auth: AuthService, private router: Router) { }

  showPassword = false;

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  onRegister() {
    const payload = {
      name: this.name,
      email: this.email,
      password: this.password,
      age: this.age,
      gender: this.gender,
      location: this.location
    };

    console.log('Register Payload:', payload); // 🔍 DEBUG

    this.auth.register(payload).subscribe({
      next: (res) => {
        this.auth.setToken(res.token); // Save token
        this.auth.getUserInfo().subscribe(user => {
          localStorage.setItem('user', JSON.stringify(user));
          this.success = 'Registration successful!';
          this.error = '';
          this.router.navigate(['/dashboard']);
        });
      },
      error: () => {
        this.error = 'Something went wrong. Please try again.';
        this.success = '';
      }
    });
  }
}